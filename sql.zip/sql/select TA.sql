select * from LogonAudit.dbo.LogonAuditing

select * from Northwind_Audit.dbo.northwind_procedure_list
select * from Northwind_Audit.dbo.northwind_table_list
select * from Northwind_Audit.dbo.northwind_view_list
select * from Northwind_Audit.dbo.northwind_function_list
select * from Northwind_Audit.dbo.northwind_trigger_list

select * from Northwind_Audit.dbo.northwind_ddl_activity

select * from TESTDBAUDIT.dbo.DDL_Activity