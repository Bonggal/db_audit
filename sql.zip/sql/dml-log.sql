

Select 
	d.[Current LSN],
	b.Description,
	d.AllocUnitName,
	b.[Transaction ID],
	d.name,
	d.Operation,
	b.[Transaction Name],
	b.[Begin Time],
	c.[End Time]
from (
	Select 
		Description,
		[Transaction Name],
		Operation,
		[Transaction ID],
		[Begin Time]
	FROM sys.fn_dblog(NULL,NULL) 
	where Operation like 'LOP_begin_XACT'
) as b
inner join (
	Select 
		Operation,
		[Transaction ID],
		[End Time]
	FROM sys.fn_dblog(NULL,NULL)
	where Operation like 'LOP_commit_XACT'
) as c
on c.[Transaction ID] = b.[Transaction ID]
inner join (
	select 
		x.[Current LSN],
		x.AllocUnitName,
		x.Operation,
		x.[Transaction ID],
		z.name
	FROM sys.fn_dblog(NULL,NULL) x
	inner join sys.partitions y
	on x.PartitionId = y.partition_id
	inner join sys.objects z
	on z.object_id = y.object_id
	where z.type != 'S'
)as d
on d.[Transaction ID] = b.[Transaction ID]
order by b.[Begin Time] ASC