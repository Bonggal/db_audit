create view northwind_table_list as
select TABLE_SCHEMA, TABLE_NAME 
from Northwind.INFORMATION_SCHEMA.TABLES
where TABLE_TYPE='BASE TABLE'

select * from dbo.northwind_table_list

create view northwind_view_list as
select
	TABLE_SCHEMA as [SCHEMA],
	TABLE_NAME as [NAME],
	VIEW_DEFINITION as [DEFINITION] 
from Northwind.INFORMATION_SCHEMA.views

select * from northwind_view_list

create view northwind_active_view_list as
select distinct(a.VIEW_NAME)
from Northwind.INFORMATION_SCHEMA.VIEW_TABLE_USAGE as a join Northwind.INFORMATION_SCHEMA.VIEWS as b
on a.VIEW_NAME = b.TABLE_NAME

select * from dbo.northwind_active_view_list

create view northwind_procedure_list as
SELECT 
	id as [ProcedureId],
	name as [ProcedureName],
	crdate as [CreateDate]
	select*
FROM northwind.dbo.sysobjects
WHERE (type = 'V')

select * from dbo.northwind_procedure_list

create view northwind_trigger_list as
use TESTDB
select 
	[so].[name] AS [trigger_name],
	OBJECT_NAME(so.parent_obj, DB_ID('Northwind') ) as [table_used],
	OBJECTPROPERTY( [so].[id], 'ExecIsUpdateTrigger') AS [isupdate],
    OBJECTPROPERTY( [so].[id], 'ExecIsDeleteTrigger') AS [isdelete],
    OBJECTPROPERTY( [so].[id], 'ExecIsInsertTrigger') AS [isinsert],
	OBJECTPROPERTY([so].[id], 'ExecIsTriggerDisabled') AS [disabled],
	crdate as [create_date]
from Northwind.dbo.sysobjects as so
where so.[type] = 'TR' 


SELECT
    [so].[name] AS [trigger_name],
    USER_NAME([so].[uid]) AS [trigger_owner],
    USER_NAME([so2].[uid]) AS [table_schema],
    OBJECT_NAME([so].[parent_obj]) AS [table_name],
    OBJECTPROPERTY( [so].[id], 'ExecIsUpdateTrigger') AS [isupdate],
    OBJECTPROPERTY( [so].[id], 'ExecIsDeleteTrigger') AS [isdelete],
    OBJECTPROPERTY( [so].[id], 'ExecIsInsertTrigger') AS [isinsert],
    OBJECTPROPERTY( [so].[id], 'ExecIsAfterTrigger') AS [isafter],
    OBJECTPROPERTY( [so].[id], 'ExecIsInsteadOfTrigger') AS [isinsteadof],
    OBJECTPROPERTY([so].[id], 'ExecIsTriggerDisabled') AS [disabled] 
FROM sysobjects AS [so]
INNER JOIN sysobjects AS so2 ON so.parent_obj = so2.Id
WHERE [so].[type] = 'TR'


SELECT user_name(uid) as [username],* 
FROM sysusers

create view northwind_failed_logon as


Exec master.sys.sp_readerrorlog 1, 1, 'Login failed' 

SELECT
 [Current LSN],
 [Transaction ID],
 [Operation],
  [Transaction Name],
 [CONTEXT],
 [AllocUnitName],
 [Page ID],
 [Slot ID],
 [Begin Time],
 [End Time],
 [Number of Locks],
 [Lock Information]
FROM northwind.sys.fn_dblog(NULL,NULL)
where Operation in (
	'LOP_MODIFY_ROW',
	'LOP_INSERT_ROW',
	'LOP_DELETE_ROW'
)

-- last modified dat of table
SELECT * FROM sys.tables  
WHERE object_id = 245575913;  

SELECT a.[name] as 'Table',
b.[name] as 'Column',
c.[name] as 'Datatype',
b.[length] as 'Length',
CASE
WHEN b.[cdefault] > 0 THEN d.[text]
ELSE NULL
END as 'Default',
CASE
WHEN b.[isnullable] = 0 THEN 'No'
ELSE 'Yes'
END as 'Nullable'
FROM sysobjects a
INNER JOIN syscolumns b
ON a.[id] = b.[id]
INNER JOIN systypes c
ON b.[xtype] = c.[xtype]
LEFT JOIN syscomments d
ON b.[cdefault] = d.[id]
WHERE a.[xtype] = 'u'
-- 'u' for user tables, 'v' for views.
--and a.[name]='table name'
AND a.[name] <> 'dtproperties'
ORDER BY a.[name],b.[colorder] 