-- drop table Northwind_Audit.dbo.NorthwindTable
select 
	so.id as [TableID],
	so.name as [TableName],
	so.[uid] as [SchemaID],
	so.crdate as [CreateDate],
	o.modify_date as [ModifyDate]
--into Northwind_Audit.dbo.NorthwindTable
from Northwind.sys.sysobjects as so
inner join Northwind.sys.objects as o
on so.id = o.object_id
where so.type='u'
	
select *
from Northwind.sys.objects
where type='u'

truncate table Northwind_Audit.dbo.NorthwindTable
select * from Northwind_Audit.dbo.NorthwindTable

MERGE INTO Northwind_Audit.dbo.NorthwindTable T
   USING (
          SELECT 
			so.id as [TableID],
			so.name as [TableName],
			so.[uid] as [SchemaID],
			so.crdate as [CreateDate],
			o.modify_date as [ModifyDate]
          from 
			Northwind.sys.sysobjects as so
			inner join Northwind.sys.objects as o 
			on so.id = o.object_id
         ) S
      ON T.TableID = S.TableID
WHEN MATCHED THEN
   UPDATE 
      SET [TableID] = S.[TableID], 
          [TableName] = S.[TableName],
		  [SchemaID] = S.[SchemaID],
		  [CreateDate] = S.[CreateDate],
		  [ModifyDate] = S.[ModifyDate];

		  ObjectID int NOT NULL Primary key,
	ObjectType nvarchar(120) not null,
	ObjectName nvarchar(120) not null,
	SchemaID int null,
	CreateDate datetime not null,
	ModifyDate datetime null,
	[Definition] nvarchar(4000) null