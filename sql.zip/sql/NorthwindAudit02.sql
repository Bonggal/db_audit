create table DatabaseObjects
(
	ObjectID int NOT NULL Primary key,
	ObjectType nvarchar(120) not null,
	ObjectName nvarchar(120) not null,
	SchemaID int null,
	CreateDate datetime not null,
	ModifyDate datetime null,
	[Definition] nvarchar(4000) null
)

select * from NorthwindAudit02.dbo.DatabaseObjects
order by ObjectType ASC

create table NorthwindTables
(
	ObjectID int NOT NULL Primary key,
	ObjectType varchar(5) not null,
	ObjectName nvarchar(120) not null,
	SchemaID int null,
	CreateDate datetime not null,
	ModifyDate datetime null
)

select * from NorthwindTables

-- Merge Table Information
MERGE INTO NorthwindAudit02.dbo.DatabaseObjects T
   USING (
          SELECT 
			so.id as [TableID],
			so.name as [TableName],
			so.[uid] as [SchemaID],
			so.crdate as [CreateDate],
			o.modify_date as [ModifyDate]
          from 
			Northwind.sys.sysobjects as so
			inner join Northwind.sys.objects as o 
			on so.id = o.object_id
		  where so.type='u'
         ) S
      ON T.ObjectID = S.TableID
when NOT MATCHED then
		insert (ObjectID, ObjectType, ObjectName, SchemaID, CreateDate, ModifyDate, [Definition])
		values (S.TableID, 'Table', S.TableName, S.SchemaID, S.CreateDate, S.ModifyDate, '' )
WHEN MATCHED THEN
   UPDATE 
      SET ObjectID = S.[TableID], 
          ObjectType = 'Table',
		  ObjectName = S.[TableName],
		  SchemaID = S.[SchemaID],
		  CreateDate = S.[CreateDate],
		  ModifyDate = S.[ModifyDate],
		  [Definition] = '';


-- Merge View Information
MERGE INTO NorthwindAudit02.dbo.DatabaseObjects T
	USING (
		select 
			sys.id as [TableID],
			sys.name as TableName,
			sys.[uid] as SchemaID,
			sys.crdate as CreateDate,
			obj.modify_date as ModifyDate,
			inf.VIEW_DEFINITION as [Definition]
		from Northwind.dbo.sysobjects as [sys]
			inner join Northwind.INFORMATION_SCHEMA.VIEWS as [inf]
			on sys.name=inf.TABLE_NAME
			inner join Northwind.sys.objects as obj
			on sys.id = obj.object_id
		where sys.type='v'
    ) S
    ON T.ObjectID = S.TableID
	when NOT MATCHED then
		insert (ObjectID, ObjectType, ObjectName, SchemaID, CreateDate, ModifyDate, [Definition])
		values (S.TableID, 'View', S.TableName, S.SchemaID, S.CreateDate, S.ModifyDate, [Definition] )
	WHEN MATCHED THEN
	UPDATE 
	SET ObjectID = S.[TableID], 
		ObjectType = 'View',
		ObjectName = S.[TableName],
		SchemaID = S.[SchemaID],
		CreateDate = S.[CreateDate],
		ModifyDate = S.[ModifyDate],
		[Definition] = S.[Definition];

-- Merge Function Information
MERGE INTO NorthwindAudit02.dbo.DatabaseObjects T
	USING (
		select 
			so.id as TableID,
			so.name as TableName,
			so.uid as [SchemaID],
			so.crdate as CreateDate,
			o.modify_date as ModifyDate,
			m.definition as [Definition]
		from Northwind.sys.sysobjects as so
			inner join Northwind.sys.sql_modules as m
			on so.id = m.[object_id]
			inner join Northwind.sys.objects as o
			on so.id = o.object_id
		where so.type = 'Fn'
    ) S
    ON T.ObjectID = S.TableID
	when NOT MATCHED then
		insert (ObjectID, ObjectType, ObjectName, SchemaID, CreateDate, ModifyDate, [Definition])
		values (S.TableID, 'Function', S.TableName, S.SchemaID, S.CreateDate, S.ModifyDate, [Definition] )
	WHEN MATCHED THEN
	UPDATE 
	SET ObjectID = S.[TableID], 
		ObjectType = 'Function',
		ObjectName = S.[TableName],
		SchemaID = S.[SchemaID],
		CreateDate = S.[CreateDate],
		ModifyDate = S.[ModifyDate],
		[Definition] = S.[Definition];

-- Merge Stored Procedure Information
MERGE INTO NorthwindAudit02.dbo.DatabaseObjects T
	USING (
		select 
			so.id as TableID,
			so.name as TableName,
			so.uid as SchemaID,
			so.crdate as CreateDate,
			obj.modify_date as ModifyDate,
			m.definition as Definition
		from Northwind.sys.sysobjects as so
			inner join Northwind.sys.sql_modules as m
			on so.id = m.[object_id]
			inner join Northwind.sys.objects as obj
			on so.id = obj.object_id
		where so.type = 'P'
    ) S
    ON T.ObjectID = S.TableID
	when NOT MATCHED then
		insert (ObjectID, ObjectType, ObjectName, SchemaID, CreateDate, ModifyDate, [Definition])
		values (S.TableID, 'Stored Procedure', S.TableName, S.SchemaID, S.CreateDate, S.ModifyDate, [Definition] )
	WHEN MATCHED THEN
	UPDATE 
	SET ObjectID = S.[TableID], 
		ObjectType = 'Stored Procedure',
		ObjectName = S.[TableName],
		SchemaID = S.[SchemaID],
		CreateDate = S.[CreateDate],
		ModifyDate = S.[ModifyDate],
		[Definition] = S.[Definition];