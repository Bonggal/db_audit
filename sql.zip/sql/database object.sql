use Northwind
go

select * from Northwind.INFORMATION_SCHEMA.views
select * from Northwind.INFORMATION_SCHEMA.VIEW_TABLE_USAGE
select * from Northwind.INFORMATION_SCHEMA.VIEW_COLUMN_USAGE order by VIEW_NAME asc

select
	[view].TABLE_CATALOG as [Database],
	[view].TABLE_SCHEMA as [Schema],
	[view].TABLE_NAME as [Name],
	[view].VIEW_DEFINITION as [Definition],
	usage.TABLE_CATALOG as [RefDatabase],
	usage.TABLE_NAME as [RefTable],
	usage.COLUMN_NAME as [RefColumn]
from Northwind.INFORMATION_SCHEMA.VIEWS as [view]
inner join
Northwind.INFORMATION_SCHEMA.VIEW_COLUMN_USAGE as [usage]
on [view].TABLE_NAME = usage.VIEW_NAME
order by Name ASC

select * from INFORMATION_SCHEMA.TABLES
where TABLE_TYPE='BASE TABLE'

select TABLE_SCHEMA, TABLE_NAME into Northwind_Audit.dbo.NorthwindTable
FROM INFORMATION_SCHEMA.TABLES
WHere TABLE_TYPE = 'BASE TABLE'




select count(distinct(TABLE_NAME)) from INFORMATION_SCHEMA.VIEWS
select count(distinct(a.VIEW_NAME))
from INFORMATION_SCHEMA.VIEW_TABLE_USAGE a join INFORMATION_SCHEMA.VIEWS b
on a.VIEW_NAME = b.TABLE_NAME


--
SELECT *
  FROM northwind.dbo.sysobjects
   WHERE (type = 'IF')
   order by name asc
/*
object type:
u   = table
fk  = foreign key ?
c   = c??? key
p   = stored procedure
v   = view
k   = primary key
*/

 select  distinct(type)
 from dbo.sysobjects

 SELECT name, definition, type_desc 
  FROM sys.sql_modules m 
INNER JOIN sys.objects o 
        ON m.object_id=o.object_id
WHERE type_desc like '%function%'

-- STORED PROCEDURE ==========================================
select * 
  from Northwind.information_schema.routines 
 where routine_type = 'PROCEDURE'


-- SELECT DATABASE TRIGGER ====================================
   SELECT
    [so].[name] AS [trigger_name],
    USER_NAME([so].[uid]) AS [trigger_schema],
    OBJECT_NAME([so].[parent_obj]) AS [table_name],
    OBJECTPROPERTY( [so].[id], 'ExecIsUpdateTrigger') AS [isupdate],
    OBJECTPROPERTY( [so].[id], 'ExecIsDeleteTrigger') AS [isdelete],
    OBJECTPROPERTY( [so].[id], 'ExecIsInsertTrigger') AS [isinsert],
    OBJECTPROPERTY( [so].[id], 'ExecIsAfterTrigger') AS [isafter],
    OBJECTPROPERTY( [so].[id], 'ExecIsInsteadOfTrigger') AS [isinsteadof],
    OBJECTPROPERTY([so].[id], 'ExecIsTriggerDisabled') AS [disabled] 
FROM Northwind.sys.sysobjects AS [so]
WHERE [so].[type] = 'TR'
 -- =============================================================

select
	o.id as TriggerId,
	o.name as TriggerName,
	a.name as ParentName,
	e.type_desc as TriggerType, 
	o.crdate as CreateDate
from TESTDB.sys.sysobjects as o
inner join TESTDB.sys.trigger_events as e
on o.id = e.object_id
join TESTDB.sys.sysobjects as a
on a.id = o.parent_obj
where o.type = 'TR'

select * from Northwind.sys.objects 
where type='tr'

select *
from TESTDB.sys.trigger_events as m
where m.object_id = 1045578763

--inner join TESTDB.dbo.sysobjects as s
--on m.object_id = s.id

--==================================================

select * from LogonAudit.dbo.LogonAuditing
order by LogonTime DESC

-- modified object in n days
SELECT name AS object_name   
  ,SCHEMA_NAME(schema_id) AS schema_name  
  ,type_desc  
  ,create_date  
  ,modify_date  
FROM Northwind_Audit.sys.objects  
WHERE modify_date > GETDATE() - 30  
ORDER BY modify_date;  

select * from sys.syslogins
select * from sys.sysusers
select * from sys.triggers

select
	so.name as [ObjectName],
	so.id as [ObjectID],
	so.xtype as [ObjectType],
	so.crdate as [CreateDate],
	o.modify_date as [ModifyDate],
	so.parent_obj as [ParentObject]
from Northwind.sys.sysobjects as so
inner join northwind.sys.objects as o
on so.id = o.object_id