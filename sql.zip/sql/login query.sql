-- locate sql server error log
USE master
GO
xp_readerrorlog 0, 1, N'Logging SQL Server messages in file', NULL, NULL, N'asc' 
GO

select * 
--select distinct(database_id)
from Northwind.sys.dm_exec_sessions
where database_id = DB_ID('master')
order by login_time DESC


SELECT DB_NAME(database_id) as [DB]
    , login_name
    , nt_domain
    , nt_user_name
    , status
    , host_name
    , program_name
    , COUNT(*) AS [Connections]
FROM sys.dm_exec_sessions
WHERE database_id > 0 -- OR 4 for user DBs
GROUP BY database_id, login_name, status, host_name, program_name, nt_domain, nt_user_name;

select 
	day(LogonTime) as [day],
	month(LogonTime) as [month],
	YEAR(LogonTime) as [year],
	count(LogonTime) as [total]
from LogonAudit.dbo.LogonAuditing
group by
	YEAR(LogonTime),
	month(LogonTime),
	day(LogonTime)



EXEC master.sys.sp_readerrorlog 0, 1, 'Login failed' 

EXEC sp_readerrorlog 0, 1, 'Login succeeded' 
/* 
p1: archive number
p2: 1 for error log, 2 for sql agent log
p3: only when 'login failed appear'
*/

create table northwind_audit.dbo.test
(
	id int identity(1,1) primary key,
	logdate datetime,
	processinfo varchar(50),
	[Text] varchar(200)
)

insert into Northwind_Audit.dbo.test
(
	logdate,
	processinfo,
	[Text]
)



truncate table Northwind_Audit.dbo.test

select * from Northwind_Audit.dbo.test
order by logdate asc

INSERT Northwind_Audit.dbo.test EXECUTE  master.sys.sp_readerrorlog 0, 1, 'Login failed' 
INSERT Northwind_Audit.dbo.test EXECUTE  master.sys.sp_readerrorlog 1, 1, 'Login failed' 
INSERT Northwind_Audit.dbo.test EXECUTE  master.sys.sp_readerrorlog 2, 1, 'Login failed' 
INSERT Northwind_Audit.dbo.test EXECUTE  master.sys.sp_readerrorlog 3, 1, 'Login failed' 
INSERT Northwind_Audit.dbo.test EXECUTE  master.sys.sp_readerrorlog 4, 1, 'Login failed' 
INSERT Northwind_Audit.dbo.test EXECUTE  master.sys.sp_readerrorlog 5, 1, 'Login failed' 
INSERT Northwind_Audit.dbo.test EXECUTE  master.sys.sp_readerrorlog 6, 1, 'Login failed' 
INSERT Northwind_Audit.dbo.test EXECUTE  master.sys.sp_readerrorlog 7, 1, 'Login failed' 
INSERT Northwind_Audit.dbo.test EXECUTE  master.sys.sp_readerrorlog 8, 1, 'Login failed' 
INSERT Northwind_Audit.dbo.test EXECUTE  master.sys.sp_readerrorlog 9, 1, 'Login failed' 
INSERT Northwind_Audit.dbo.test EXECUTE  master.sys.sp_readerrorlog 10, 1, 'Login failed' 
INSERT Northwind_Audit.dbo.test EXECUTE  master.sys.sp_readerrorlog 11, 1, 'Login failed' 
INSERT Northwind_Audit.dbo.test EXECUTE  master.sys.sp_readerrorlog 12, 1, 'Login failed' 
INSERT Northwind_Audit.dbo.test EXECUTE  master.sys.sp_readerrorlog 13, 1, 'Login failed' 

select 
	day(logdate) as [Day],
	month(logdate) as [Month],
	year(logdate) as [Year],
	count(logdate) as [Total]
from Northwind_Audit.dbo.test
group by
	year(logdate),
	month(logdate),
	day(logdate)

truncate table Northwind_Audit.dbo.test 
select * from Northwind_Audit.dbo.test

drop table [DatabaseFailedAcess]

-- Failed acces table
CREATE TABLE [dbo].[DatabaseFailedAccess](
	[id] [int] IDENTITY(1,1) PRIMARY KEY NOT NULL,
	[LogDate] [datetime] NULL,
	[ProcessInfo] [varchar](50) NULL,
	[Text] [varchar](200) NULL
)

-- GET FAILED ACCESS LOG FROM SQL SERVER LOG
Declare @FailedAccess table(
	[LogDate] datetime, 
	[ProcessInfo] nvarchar(20), 
	[Text] nvarchar(4000)
)
insert into @FailedAccess([LogDate],[ProcessInfo],[Text]) 
exec master.sys.sp_readerrorlog 1, 1, 'Login failed'

SELECT [LogDate],[ProcessInfo],[Text]
FROM @FailedAccess

-- MERGE THE LOG
Declare @FailedAccess table(
	[LogDate] datetime, 
	[ProcessInfo] nvarchar(20), 
	[Text] nvarchar(4000)
)

insert into @FailedAccess([LogDate],[ProcessInfo],[Text]) 
exec master.sys.sp_readerrorlog 1, 1, 'Login failed'

MERGE INTO NorthwindAudit02.dbo.DatabaseFailedAccess T
USING (
	SELECT [LogDate],[ProcessInfo],[Text]
	FROM @FailedAccess
) S
ON T.LogDate = S.LogDate
when NOT MATCHED then
	insert (LogDate, ProcessInfo, Text)
	values (S.LogDate, S.ProcessInfo, S.Text)
WHEN MATCHED THEN
	UPDATE 
	SET LogDate = S.LogDate, 
		ProcessInfo = S.ProcessInfo,
		Text = S.Text;

select * from NorthwindAudit02.dbo.DatabaseFailedAccess