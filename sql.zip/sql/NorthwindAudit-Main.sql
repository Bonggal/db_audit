CREATE TABLE [dbo].[DatabaseAccessLog](
	[LogID] 	[int] IDENTITY(1,1) PRIMARY KEY NOT NULL,
	[LoginName] 	[varchar](50) 	NULL,
	[ProgramName]	[varchar](500) 	NULL,
	[AccessTime] 	[datetime] 	NULL
)
