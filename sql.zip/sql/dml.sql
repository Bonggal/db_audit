Select *
FROM sys.fn_dblog(NULL,NULL)
WHERE Operation LIKE '%BEGIN_XACT%'

Select 
	a.[Current LSN],
	a.Operation,
	a.[Transaction ID],
	a.[Begin Time],
	c.name,
	c.modify_date
FROM sys.fn_dblog(NULL,NULL) a
inner join sys.partitions b
	on a.PartitionId = b.partition_id
inner join sys.objects c
	on b.object_id = c.object_id
inner join sys.fn_dblog(null, null) d
	on d.[Transaction ID]


select *
from sys.objects

select *
from sys.partitions