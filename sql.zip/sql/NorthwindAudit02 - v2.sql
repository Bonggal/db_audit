-- Create Table for Object Dependency
CREATE TABLE ObjectDependency
(
	DependID int identity(1,1) primary key,
	ObjectID int,
	DatabaseObject varchar(500),
	DependObjectID int,
	DependObject varchar(500),
	DependObjectType varchar(5)
)

drop table ObjectDependency

-- Create Table Table Information
create table NorthwindTables
(
	ObjectID int NOT NULL Primary key,
	ObjectType varchar(5) not null,
	ObjectName nvarchar(120) not null,
	SchemaID int null,
	CreateDate datetime not null,
	ModifyDate datetime null,
	[Definition] nvarchar(4000) null
)

-- Create View Table Information
create table NorthwindView
(
	ObjectID int NOT NULL Primary key,
	ObjectType varchar(5) not null,
	ObjectName nvarchar(120) not null,
	SchemaID int null,
	CreateDate datetime not null,
	ModifyDate datetime null,
	[Definition] nvarchar(4000) null
)

-- Create Function Table Information
create table NorthwindFunction
(
	ObjectID int NOT NULL Primary key,
	ObjectType varchar(5) not null,
	ObjectName nvarchar(120) not null,
	SchemaID int null,
	CreateDate datetime not null,
	ModifyDate datetime null,
	[Definition] nvarchar(4000) null
)

-- Create Stored Procedure Table Information
create table NorthwindSProcedures
(
	ObjectID int NOT NULL Primary key,
	ObjectType varchar(5) not null,
	ObjectName nvarchar(120) not null,
	SchemaID int null,
	CreateDate datetime not null,
	ModifyDate datetime null,
	[Definition] nvarchar(4000) null
)

-- Create Trigger Table Information
create table NorthwindTriggers
(
	ObjectID int NOT NULL Primary key,
	ObjectType varchar(5) not null,
	ObjectName nvarchar(120) not null,
	SchemaID int null,
	CreateDate datetime not null,
	ModifyDate datetime null,
	[Definition] nvarchar(4000) null
)

-- Create Schema Information
CREATE TABLE NorthwindSchemas
(
	SchemaID int primary key NOT NULL,
	PrincipalID int NOT NULL,
	SchemaName nvarchar(255) NOT NULL
)


-- Select All Table Information
Select * from NorthwindTables
select * from NorthwindView
select * from NorthwindFunction
select * from NorthwindTrigger
select * from NorthwindSProcedure




-- Merge Table Information
MERGE INTO NorthwindAudit02.dbo.NorthwindTables T
USING (
	SELECT 
		so.id as [TableID],
		so.type as [Type],
		so.name as [TableName],
		so.[uid] as [SchemaID],
		so.crdate as [CreateDate],
		o.modify_date as [ModifyDate]
	from 
		Northwind.sys.sysobjects as so
		inner join Northwind.sys.objects as o 
		on so.id = o.object_id
	where so.type='u'
) S
ON T.ObjectID = S.TableID
when NOT MATCHED then
	insert (ObjectID, ObjectType, ObjectName, SchemaID, CreateDate, ModifyDate, [Definition])
	values (S.TableID, S.[Type], S.TableName, S.SchemaID, S.CreateDate, S.ModifyDate, '' )
WHEN MATCHED THEN
	UPDATE 
	SET ObjectID = S.[TableID], 
		ObjectType = S.[Type],
		ObjectName = S.[TableName],
		SchemaID = S.[SchemaID],
		CreateDate = S.[CreateDate],
		ModifyDate = S.[ModifyDate],
		[Definition] = '';

-- Merge View Information
MERGE INTO NorthwindAudit02.dbo.NorthwindView T
USING (
	select 
			sys.id as [TableID],
			sys.type as [Type],
			sys.name as TableName,
			sys.[uid] as SchemaID,
			sys.crdate as CreateDate,
			obj.modify_date as ModifyDate,
			inf.VIEW_DEFINITION as [Definition]
		from Northwind.dbo.sysobjects as [sys]
			inner join Northwind.INFORMATION_SCHEMA.VIEWS as [inf]
			on sys.name=inf.TABLE_NAME
			inner join Northwind.sys.objects as obj
			on sys.id = obj.object_id
		where sys.type='v'
) S
ON T.ObjectID = S.TableID
when NOT MATCHED then
	insert (ObjectID, ObjectType, ObjectName, SchemaID, CreateDate, ModifyDate, [Definition])
	values (S.TableID, S.[Type], S.TableName, S.SchemaID, S.CreateDate, S.ModifyDate, S.[Definition] )
WHEN MATCHED THEN
	UPDATE 
	SET ObjectID = S.[TableID], 
		ObjectType = S.[Type],
		ObjectName = S.[TableName],
		SchemaID = S.[SchemaID],
		CreateDate = S.[CreateDate],
		ModifyDate = S.[ModifyDate],
		[Definition] = S.[Definition];

-- Merge Trigger Information
MERGE INTO NorthwindAudit02.dbo.NorthwindTrigger T
USING (
	select 
		tr.object_id as TriggerID,
		tr.type as TriggerType,
		tr.name as TriggerName,
		ob.schema_id as SchemaID,
		tr.create_date as CreateDate,
		tr.modify_date as ModifyDate,
		mo.definition as [Definition],
		sed.referenced_id as DependObjectID,
		Object_name(sed.referenced_id) as DependObjectName,
		tr.is_disabled as Status
	from  Northwind.sys.triggers as tr
		left join Northwind.sys.objects as ob
		on tr.object_id=ob.object_id
		inner join Northwind.sys.sql_modules as mo
		on tr.object_id = mo.object_id
		inner join Northwind.sys.sql_expression_dependencies as sed
		on sed.referencing_id = tr.object_id

) S
ON T.ObjectID = S.TriggerID
when NOT MATCHED then
	insert (ObjectID, ObjectType, ObjectName, SchemaID, CreateDate, ModifyDate, [Definition])
	values (S.TriggerID, S.[TriggerType], S.TriggerName, S.SchemaID, S.CreateDate, S.ModifyDate, S.[Definition] )
WHEN MATCHED THEN
	UPDATE 
	SET ObjectID = S.TriggerID, 
		ObjectType = S.[TriggerType],
		ObjectName = S.TriggerName,
		SchemaID = S.[SchemaID],
		CreateDate = S.[CreateDate],
		ModifyDate = S.[ModifyDate],
		[Definition] = S.[Definition];

-- Merge Stored Procedure Information
MERGE INTO NorthwindAudit.dbo.NorthwindSProcedures T
USING (
	select 
			so.id as ProcID,
			so.type as ProcType,
			so.name as ProcName,
			so.uid as SchemaID,
			so.crdate as CreateDate,
			obj.modify_date as ModifyDate,
			m.definition as Definition,
			sed.referenced_id as DependObjectID,
			sed.referenced_entity_name as DependObjectName
		from Northwind.sys.sysobjects as so
			inner join Northwind.sys.sql_modules as m
			on so.id = m.[object_id]
			inner join Northwind.sys.objects as obj
			on so.id = obj.object_id
			inner join Northwind.sys.sql_expression_dependencies as sed
			on sed.referencing_id = so.id
		where so.type = 'P'
) S
ON T.ObjectID = S.ProcID
when NOT MATCHED then
	insert (ObjectID, ObjectType, ObjectName, SchemaID, CreateDate, ModifyDate, [Definition])
	values (S.ProcID, S.[ProcType], S.ProcName, S.SchemaID, S.CreateDate, S.ModifyDate, S.[Definition] )
WHEN MATCHED THEN
	UPDATE 
	SET ObjectID = S.ProcID, 
		ObjectType = S.[ProcType],
		ObjectName = S.ProcName,
		SchemaID = S.[SchemaID],
		CreateDate = S.[CreateDate],
		ModifyDate = S.[ModifyDate],
		[Definition] = S.[Definition];

-- Merge Function Information
MERGE INTO NorthwindAudit.dbo.NorthwindFunction T
USING (
	select 
			so.id as FunctionID,
			so.type as FunctionType,
			so.name as FunctionName,
			so.uid as SchemaID,
			so.crdate as CreateDate,
			obj.modify_date as ModifyDate,
			m.definition as Definition
		from Northwind.sys.sysobjects as so
			inner join Northwind.sys.sql_modules as m
			on so.id = m.[object_id]
			inner join Northwind.sys.objects as obj
			on so.id = obj.object_id
		where so.type = 'FN'
) S
ON T.ObjectID = S.FunctionID
when NOT MATCHED then
	insert (ObjectID, ObjectType, ObjectName, SchemaID, CreateDate, ModifyDate, [Definition])
	values (S.FunctionID, S.[FunctionType], S.FunctionName, S.SchemaID, S.CreateDate, S.ModifyDate, S.[Definition] )
WHEN MATCHED THEN
	UPDATE 
	SET ObjectID = S.FunctionID, 
		ObjectType = S.[FunctionType],
		ObjectName = S.FunctionName,
		SchemaID = S.[SchemaID],
		CreateDate = S.[CreateDate],
		ModifyDate = S.[ModifyDate],
		[Definition] = S.[Definition];

-- Merge Object Dependency Information for View
Declare @SQL nvarchar(max)
set @SQL = N'
USE Northwind
MERGE INTO NorthwindAudit.dbo.ObjectDependency T
   USING (
			select 
				Object_ID(t1.TABLE_NAME) as ObjectID,
				t1.TABLE_NAME as DatabaseObject,
				Object_ID(t2.TABLE_NAME) as DependObjectID,
				t2.TABLE_NAME as DependObject,
				so.type as DependObjectType
			from Northwind.INFORMATION_SCHEMA.VIEWS as t1
				inner join Northwind.INFORMATION_SCHEMA.VIEW_TABLE_USAGE as t2
				on t1.TABLE_NAME = t2.VIEW_NAME
				inner join sys.objects as so
				on so.object_id = Object_ID(t2.TABLE_NAME)
         ) S
      ON T.DatabaseObject = S.DatabaseObject and
	  T.DependObject = S.DependObject 
when NOT MATCHED then
		insert (ObjectID, DatabaseObject,DependObjectID, DependObject, DependObjectType)
		values (S.ObjectID, S.DatabaseObject,S.DependObjectID, S.DependObject, S.DependObjectType)
WHEN MATCHED THEN
   UPDATE 
      SET ObjectID = S.ObjectID,
		  DatabaseObject = S.DatabaseObject, 
          DependObject = S.DependObject,
		  DependObjectID = S.DependObjectID,
		  DependObjectType = S.DependObjectType;
'
EXEC SP_executesql @SQL

-- Create View to Display Northwind's View Dependecy
alter view ObjectDependencyView as
	select 
		DependID,
		ObjectID,
		DatabaseObject,
		DependObjectID,
		DependObject,
		DependObjectType as DependObjectType
	from ObjectDependency

select * from ObjectDependencyView


-- GET IP ADDRESS
SELECT  hostname,
        net_library,
        net_address,
        client_net_address
FROM    sys.sysprocesses AS S
INNER JOIN    sys.dm_exec_connections AS decc ON S.spid = decc.session_id
WHERE   spid = @@SPID

